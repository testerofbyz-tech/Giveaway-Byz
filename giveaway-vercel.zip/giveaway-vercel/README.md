# Giveaway — Tukar Kode Redeem

Frontend statis (`index.html`) + 2 serverless function (`/api/redeem`, `/api/admin`).
Data kode disimpan di Upstash Redis. Tanpa dependency npm.

## Deploy ke Vercel

1. Upload folder ini ke GitHub, lalu **Add New → Project** di Vercel dan import repo-nya
   (atau jalankan `npx vercel` dari folder ini).
2. Di project Vercel: **Storage → Create → Upstash (Redis)**, lalu **Connect Project**.
   Variabel `KV_REST_API_URL` dan `KV_REST_API_TOKEN` otomatis ditambahkan.
3. Di **Settings → Environment Variables** tambahkan:
   - `ADMIN_PASSWORD` = password admin kamu (buat yang panjang & unik)
4. **Redeploy** supaya variabel terbaca.

## Cara pakai

- Peserta: buka web, masukin kode, klaim.
- Admin: klik tombol **Admin** di bawah, masukin `ADMIN_PASSWORD`, lalu tambah/hapus kode.

## Tes lokal

```
npx vercel link
npx vercel env pull .env.local
npx vercel dev
```
