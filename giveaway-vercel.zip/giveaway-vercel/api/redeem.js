const { redis, norm, body, limit, KEY } = require('./_lib');

// Atomik: cek kode, pastikan belum dipakai, tandai terklaim — dalam satu langkah
const LUA = `
local v = redis.call('HGET', KEYS[1], ARGV[1])
if not v then return 'NOTFOUND' end
local d = cjson.decode(v)
if d.claimedAt then return 'USED' end
d.claimedAt = tonumber(ARGV[2])
redis.call('HSET', KEYS[1], ARGV[1], cjson.encode(d))
return 'OK:' .. tostring(d.prize)
`;

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ status: 'ERROR' });
  try {
    if (!(await limit(req, 'redeem', 10))) return res.status(429).json({ status: 'RATE' });
    const code = norm(body(req).code);
    if (code.length < 3) return res.status(400).json({ status: 'EMPTY' });
    const r = await redis('EVAL', LUA, 1, KEY, code, String(Date.now()));
    if (r === 'NOTFOUND') return res.status(200).json({ status: 'INVALID' });
    if (r === 'USED') return res.status(200).json({ status: 'USED' });
    if (typeof r === 'string' && r.startsWith('OK:'))
      return res.status(200).json({ status: 'OK', prize: r.slice(3) });
    return res.status(500).json({ status: 'ERROR' });
  } catch (e) {
    return res.status(500).json({ status: 'ERROR', message: e.message });
  }
};
