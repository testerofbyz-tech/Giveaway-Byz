const crypto = require('crypto');
const { redis, pipeline, norm, body, limit, isAdmin, KEY } = require('./_lib');

const ALPHA = 'ABCDEFGHJKMNPQRSTUVWXYZ23456789';
const part = (n) => Array.from({ length: n }, () => ALPHA[crypto.randomInt(ALPHA.length)]).join('');
const gen = () => `GIVE-${part(4)}-${part(4)}`;

module.exports = async (req, res) => {
  if (req.method !== 'POST') return res.status(405).json({ error: 'method' });
  try {
    if (!(await limit(req, 'admin', 30))) return res.status(429).json({ error: 'RATE' });
    if (!isAdmin(req)) return res.status(401).json({ error: 'UNAUTHORIZED' });

    const b = body(req);

    if (b.action === 'list') {
      const flat = (await redis('HGETALL', KEY)) || [];
      const items = [];
      for (let i = 0; i < flat.length; i += 2) {
        try { items.push(JSON.parse(flat[i + 1])); } catch (e) {}
      }
      items.sort((a, b) => (b.createdAt || 0) - (a.createdAt || 0));
      return res.status(200).json({ items });
    }

    if (b.action === 'add') {
      const prize = String(b.prize || '').trim().slice(0, 80);
      if (!prize) return res.status(400).json({ error: 'NO_PRIZE' });
      const custom = norm(b.code);
      const qty = custom ? 1 : Math.max(1, Math.min(50, parseInt(b.qty, 10) || 1));
      const now = Date.now();
      const codes = Array.from({ length: qty }, () => custom || gen());
      const out = await pipeline(
        codes.map((code, i) => ['HSETNX', KEY, code, JSON.stringify({ code, prize, createdAt: now + i })])
      );
      const added = out.filter((o) => o.result === 1).length;
      if (!added) return res.status(409).json({ error: 'EXISTS' });
      return res.status(200).json({ added });
    }

    if (b.action === 'delete') {
      await redis('HDEL', KEY, norm(b.code));
      return res.status(200).json({ ok: true });
    }

    return res.status(400).json({ error: 'BAD_ACTION' });
  } catch (e) {
    return res.status(500).json({ error: 'ERROR', message: e.message });
  }
};
