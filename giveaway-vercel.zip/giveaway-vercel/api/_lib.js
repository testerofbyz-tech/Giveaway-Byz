const crypto = require('crypto');

const URL_ = process.env.KV_REST_API_URL || process.env.UPSTASH_REDIS_REST_URL;
const TOKEN = process.env.KV_REST_API_TOKEN || process.env.UPSTASH_REDIS_REST_TOKEN;
const KEY = 'giveaway:codes';

async function call(path, payload) {
  if (!URL_ || !TOKEN) throw new Error('Database belum dikonfigurasi');
  const r = await fetch(URL_ + path, {
    method: 'POST',
    headers: { Authorization: 'Bearer ' + TOKEN, 'Content-Type': 'application/json' },
    body: JSON.stringify(payload),
  });
  const j = await r.json();
  if (!r.ok || (j && j.error)) throw new Error((j && j.error) || 'Redis error');
  return j;
}

// satu perintah: redis('HGET', key, field)
const redis = async (...cmd) => (await call('', cmd)).result;
// banyak perintah sekaligus: pipeline([['INCR','k'],['EXPIRE','k',60]])
const pipeline = async (cmds) => call('/pipeline', cmds);

const norm = (s) => String(s || '').toUpperCase().replace(/\s+/g, '').slice(0, 40);

function body(req) {
  if (typeof req.body === 'string') {
    try { return JSON.parse(req.body); } catch (e) { return {}; }
  }
  return req.body || {};
}

const ip = (req) => (req.headers['x-forwarded-for'] || '').split(',')[0].trim() || 'unknown';

// batas percobaan per IP per menit
async function limit(req, name, max) {
  const k = `giveaway:rl:${name}:${ip(req)}`;
  const r = await pipeline([['INCR', k], ['EXPIRE', k, 60]]);
  return Number(r[0].result) <= max;
}

function isAdmin(req) {
  const pw = process.env.ADMIN_PASSWORD;
  if (!pw) return false;
  const h = (s) => crypto.createHash('sha256').update(String(s)).digest();
  return crypto.timingSafeEqual(h(req.headers['x-admin-password'] || ''), h(pw));
}

module.exports = { redis, pipeline, norm, body, limit, isAdmin, KEY };
